
public class Trapezio extends Poligono {

	
	public Trapezio(int base, int altura) {
		super(base, altura);
		// TODO Auto-generated constructor stub
	}

public double area() {
		
		return super.area()/2;
	}
	
	
	
	
	
	@Override
	public double perimetro() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	
	
	
}

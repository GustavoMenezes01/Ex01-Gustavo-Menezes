
public abstract class Retangulo extends Poligono {

	public Retangulo(int base, int altura) {
		super(base, altura);
		// TODO Auto-generated constructor stub
	}

	
	public double area() {
		return getBase()*getAltura();
		
		
		
	}
	
public double calculaDiagonal() {
		
		
		return 0;
	}


	@Override
	public double perimetro() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	
}

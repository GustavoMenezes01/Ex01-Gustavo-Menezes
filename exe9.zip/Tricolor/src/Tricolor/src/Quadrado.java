
public class Quadrado extends Poligono implements Diagonal {

	public Quadrado(int lado) {
		super(lado, lado);
		
	}


	public double calculaDiagonal() {
		
		
		return 0;
	}


	@Override
	public double perimetro() {
		// TODO Auto-generated method stub
		return 0;
	}


}

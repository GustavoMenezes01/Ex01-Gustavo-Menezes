
public class Poligono3D  extends Figura {

	
	
	
	public double volume() {
		return 0;
	}

	@Override
	public double area() {
		// TODO Auto-generated method stub
		return 0;
	}
}


public class Cubo extends Poligono3D {

	
	public double volume() {
		return 0;
		
		
	}
	
}

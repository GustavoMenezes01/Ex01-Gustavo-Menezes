
public abstract class Losango extends Poligono {

	public Losango(int base, int altura) {
		super(base, altura);
	
	}

	@Override
	public double perimetro() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	
}


public abstract class Figura {

	public abstract double area ();

	public int getAltura() {
		// TODO Auto-generated method stub
		return 0;
	}

	public double perimetro() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	
	
	
	
	
}
